package com.cg.ibs.loanmgmt.service;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.exception.ExceptionMessages;
import com.cg.ibs.loanmgmt.exception.IBSException;

class BankServiceImplTest {
	private static BankServiceImpl bankService = new BankServiceImpl();

	private static LoanMaster loanMasterTemp;

	@BeforeEach
	public void init() {
		loanMasterTemp = new LoanMaster();
	}

	@AfterEach
	public void destroy() {
		loanMasterTemp = null;
	}

	// UPDATE_PRECLOSURE
	@Test
	public void updatePreClosureNotNullTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Yuvraj", "Kalra", new BigInteger("944486932517"), "ykalra");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		LoanMaster actual = bankService.updatePreClosure(loanMasterTemp);
		assertNotNull(actual);

	}

	@Test
	public void updatePreClosureNegativeTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Divyam", "Batta", new BigInteger("966325874125"), "dBatta");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		LoanMaster actual = bankService.updatePreClosure(loanMasterTemp);
		assertNotEquals(14, actual.getNumberOfEmis());
	}

	// VERIFY_LOAN
	@Test
	public void verifyLoanPositiveTest() {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Dev", "Goyal", new BigInteger("966325874125"), "dgoyal");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));
		try {
			bankService.verifyLoan(loanMasterTemp);
		} catch (Exception exp) {
			fail("Test Failed");
		}

	}

	// GET_LOAN_DETAILS_FOR_VERIFICATION

	// WRITING A WRONG OBJECT IN FUNCTION
	@Test
	public void getLoanDetailsForVerificationNeutralTest() throws IOException {
		loanMasterTemp.setAppliedDate(LocalDate.of(2018, Month.SEPTEMBER, 8));
		loanMasterTemp.setLoanType(LoanType.HOME_LOAN);
		loanMasterTemp.setEmiAmount(78954.00);
		loanMasterTemp.setInterestRate(8.5f);
		loanMasterTemp.setLoanAmount(2000000);
		loanMasterTemp.setLoanTenure(24);
		loanMasterTemp.setLoanNumber(1234);
		CustomerBean customerBean = new CustomerBean("Dev", "Goyal", new BigInteger("966325874125"), "dgoyal");
		loanMasterTemp.setCustomerBean(customerBean);
		loanMasterTemp.setNumberOfEmis(13);
		loanMasterTemp.setTotalNumberOfEmis(24);
		loanMasterTemp.setNextEmiDate(LocalDate.of(2019, 10, 14));

		assertNotNull(loanMasterTemp);
	}

	// GET_PRECLOSURE_DETAILS_FOR_VERIFICATION

	@Test
	public void getPreClosureDetailsNotNullTest()
			throws FileNotFoundException, IOException, ClassNotFoundException, IBSException {
		Map<Long, LoanMaster> tempMap2 = new HashMap<>();

		tempMap2 = bankService.getPreClosureDetailsForVerification();
		assertNotNull(tempMap2);

	}

	@Test
	public void downloadDocumentPositiveTest() throws IBSException {

		loanMasterTemp.setApplicationNumber(1021);
		boolean check = bankService.downloadDocument(loanMasterTemp.getApplicationNumber());
		assertEquals(false, check);
	}

	@Test
	public void filesAvailableTest() {
		
		assertThrows(NullPointerException.class, () -> {
		bankService.getFilesAvailable();
		});
	}
}
