package com.cg.ibs.loanmgmt.bean;

public enum LoanStatus {
	PENDING, APPROVED, DECLINED, CLOSED,PENDING_PRE_CLOSURE;
}
