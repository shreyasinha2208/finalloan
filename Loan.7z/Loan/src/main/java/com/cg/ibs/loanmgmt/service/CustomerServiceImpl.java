package com.cg.ibs.loanmgmt.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.dao.CustomerDao;
import com.cg.ibs.loanmgmt.dao.CustomerDaoImpl;
import com.cg.ibs.loanmgmt.exception.IBSException;

public class CustomerServiceImpl implements CustomerService {
	Loan loan;
	Document document = new Document();
	LoanMaster loanMaster = new LoanMaster();
	CustomerDao customerDao = new CustomerDaoImpl();
	public static final String UPLOADS_LOC = "./uploads";
	private static Logger LOGGER = Logger.getLogger(CustomerServiceImpl.class);

	public boolean loanCustomerInputVerificationService(Loan loan) {
		LOGGER.info("Input is being verified");
		boolean amountValid = loan.isValidLoanAmount(loan.getLoanAmount());
		boolean tenureValid = loan.isValidTenure(loan.getLoanTenure());
		boolean check = false;
		if (amountValid && tenureValid) {
			check = true;
		}
		return check;
	}

	@Override
	public double calculateEmi(Loan loan) {
		LOGGER.info("EMI is being calculated");
		LoanBean loanBeanTemp = new LoanBean();
		float rate = loan.getInterestRate() / (12 * 100);
		loanBeanTemp.setEmiAmount(((loan.getLoanAmount() * rate * Math.pow((rate + 1), loan.getLoanTenure()))
				/ (Math.pow((rate + 1), loan.getLoanTenure()) - 1)));
		return loanBeanTemp.getEmiAmount();
	}

	public LoanMaster getLoanValues(Loan loan, String userId)
			throws SQLException, IBSException { /* makes a master copy of the loan to be sent */
		LOGGER.info("Loan values are being fetched");
		loanMaster.setLoanAmount(loan.getLoanAmount());
		loanMaster.setEmiAmount(loan.getEmiAmount());
		loanMaster.setLoanTenure(loan.getLoanTenure());
		loanMaster.setNumberOfEmis(0);
		loanMaster.setAppliedDate(LocalDate.now());
		loanMaster.setNextEmiDate(loanMaster.getAppliedDate().plusMonths(1));
		loanMaster.setCustomerBean(getCustomerDetails(userId));
		loanMaster.setTotalNumberOfEmis(loanMaster.getLoanTenure());
		loanMaster.setApplicationNumber(customerDao.generateApplicantNumber()); /* Generates Application Number */
		loanMaster.setLoanType(loan.getLoanType());
		loanMaster.setInterestRate(loan.getInterestRate());
		loanMaster.setBalance(0);
		return loanMaster;
	}

	public CustomerBean getCustomerDetails(String userId) throws SQLException, IBSException {
		LOGGER.info("Customer details are being fetched");
		return customerDao.getCustomerDetails(userId);
	}

	public boolean uploadDocument(Document document, LoanMaster loanMaster) throws IBSException { /* Document Upload */
		LOGGER.info("Document being uploaded");
		return customerDao.uploadDocument(document, loanMaster);
	}

	public boolean sendLoanForVerification(LoanMaster loanMaster) throws IBSException {
		LOGGER.info("Loan sent for verification.");
		return customerDao.sendLoanForVerification(loanMaster);

	}

	private LoanMaster getEMIDetails(long loanNumber) {
		LOGGER.info("EMI details are being fetched");
		return customerDao.getEMIDetails(loanNumber);

	}

	private boolean verifyEmi(LoanMaster loanMaster) {
		LOGGER.info("EMI details are being verified");
		boolean check = false;
		if (loanMaster.getTotalNumberOfEmis() > loanMaster.getNumberOfEmis()) {
			check = true;
		}
		return check;
	}

	public LoanMaster verifyEmiApplicable(long loanNumber) {
		LOGGER.info("EMI applicability is being verified");
		boolean check = false;
		if (verifyEmi(getEMIDetails(loanNumber))) {
			if (getEMIDetails(loanNumber).getLoanStatus().equals(LoanStatus.APPROVED)) {
				check = true;
			}
		}
		if (check) {
			return getEMIDetails(loanNumber);
		} else {
			return null;
		}
	}

	private boolean verifyTransaction(double amountPaid, LoanMaster loanMaster) {
		LOGGER.info("EMI transaction is being verified");
		boolean result = false;
		if (amountPaid == loanMaster.getEmiAmount()) {
			result = true;
		}
		return result;
	}

	public boolean updateEMI(double amountPaid, LoanMaster loanMaster) {
		LOGGER.info("EMI is being updated");
		boolean check = false;
		if (verifyTransaction(amountPaid, loanMaster)) {
			check = customerDao.updateEMI(loanMaster);
		}
		return check;
	}

	// LoanDetails

	public List<LoanMaster> getHistory(String userId) throws SQLException, IBSException {
		LOGGER.info("History of the customer is being fetched.");
		return customerDao.getHistory(userId); /*
												 * Getting collection of all the loans related to given userId
												 */
	}

	// PreClosure Customer
	public LoanMaster getPreClosureLoanDetails(long loanNumber) {
		LOGGER.info("PreClosure detais of the customer is being fetched.");
		return getInterestRate(customerDao.getPreClosureLoanDetails(loanNumber));
	}

	private boolean verifyPreclosure(LoanMaster loanMaster) { /* Preliminary Verification */
		LOGGER.info("PreClosure has been verified.");
		boolean check = false;
		if (loanMaster.getNumberOfEmis() > (loanMaster.getTotalNumberOfEmis() / 4)) {
			check = true;
		}
		return check;
	}

	public boolean verifyLoanNumber(long loanNumber) {
		LOGGER.info("Loan number has been verified.");
		boolean check = false;
		check = customerDao.verifyLoanNumber(loanNumber);
		return check;
	}

	public boolean verifyPreClosureApplicable(long loanNumber) {
		LOGGER.info("PreClosure applicability is being checked.");
		boolean check = false;
		check = verifyPreclosure(getPreClosureLoanDetails(loanNumber));
		return check;
	}

	public double calculatePreClosure(LoanMaster loanMaster) {
		LOGGER.info("PreClosure amount is being calculated.");
		double paidAmount = loanMaster.getNumberOfEmis() * loanMaster.getEmiAmount();
		double paidInterest = loanMaster.getLoanAmount() * (Math.pow(1 + (double) loanMaster.getInterestRate() / 100.0,
				(double) loanMaster.getNumberOfEmis() / 12.0)) - loanMaster.getLoanAmount();
		double paidPrincipal = (paidAmount - paidInterest);

		return (loanMaster.getLoanAmount() - paidPrincipal);
	}

	public boolean sendPreClosureForVerification(LoanMaster loanMaster) throws FileNotFoundException, IOException {
		LOGGER.info("PreClosure is being verified.");
		return customerDao.sendPreClosureForVerification(loanMaster); /* Sending data */
	}

	private LoanMaster getInterestRate(LoanMaster loanMaster) {
		if (loanMaster.getLoanType() == LoanType.HOME_LOAN) {
			loanMaster.setInterestRate(8.5f);
		} else if (loanMaster.getLoanType() == LoanType.EDUCATION_LOAN) {
			loanMaster.setInterestRate(11.35f);
		} else if (loanMaster.getLoanType() == LoanType.PERSONAL_LOAN) {
			loanMaster.setInterestRate(10.75f);
		} else if (loanMaster.getLoanType() == LoanType.VEHICLE_LOAN) {
			loanMaster.setInterestRate(9.25f);
		}
		return loanMaster;
	}

	@Override
	public boolean verifyCustomer(String userId) throws IBSException {
		LOGGER.info("Customer is being verified.");
		return customerDao.verifyCustomer(userId);
	}

}
