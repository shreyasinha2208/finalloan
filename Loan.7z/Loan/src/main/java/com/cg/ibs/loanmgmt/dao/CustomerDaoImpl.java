package com.cg.ibs.loanmgmt.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.Document;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.exception.ExceptionMessages;
import com.cg.ibs.loanmgmt.exception.IBSException;
import com.cg.ibs.loanmgmt.util.OracleDataBaseUtil;

public class CustomerDaoImpl implements CustomerDao {

	private static LoanMaster loanMaster = new LoanMaster();
	private static CustomerBean customer = new CustomerBean();
	private static Logger LOGGER = Logger.getLogger(CustomerDaoImpl.class);

	public boolean updateEMI(LoanMaster loanMaster) {
		LOGGER.info("EMI is being updated");
		Connection connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_LOAN);) {
			preparedStatement.setInt(1, (loanMaster.getNumberOfEmis() + 1));
			LocalDate updatedNextEmiDate = loanMaster.getNextEmiDate().plusMonths(1);
			java.sql.Date date = java.sql.Date.valueOf(updatedNextEmiDate);

			preparedStatement.setDate(2, date);
			preparedStatement.setLong(3, loanMaster.getLoanNumber());
			preparedStatement.executeUpdate();
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while updating EMI.");
				System.out.println(exp12.getMessage());
			}

		}

		try (PreparedStatement preparedStatement2 = connection
				.prepareStatement(QueryMapper.GET_DETAILS_FROM_LOAN_NUMBER);) {

			preparedStatement2.setLong(1, loanMaster.getLoanNumber());
			try (ResultSet resultSet = preparedStatement2.executeQuery()) {
				if (resultSet.next()) {
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					loanMaster.setCustomerBean(customer);
					loanMaster.setApplicationNumber(resultSet.getInt("applicant_num"));
					loanMaster.setLoanAmount(resultSet.getDouble("loan_amount"));
					loanMaster.setLoanTenure(resultSet.getInt("loan_tenure"));
					loanMaster.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					loanMaster.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					loanMaster.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						loanMaster.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						loanMaster.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						loanMaster.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						loanMaster.setLoanType(LoanType.VEHICLE_LOAN);
					}
					loanMaster.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					loanMaster.setNextEmiDate(resultSet.getDate("next_emi_date").toLocalDate());
				}
			}
		} catch (SQLException exp1) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp) {
				LOGGER.error("SQL Exception occuring while updating EMI.");
				System.out.println(exp.getMessage());
			}
		}

		return true;
	}

	public LoanMaster getEMIDetails(long loanNumber) {
		LOGGER.info("EMI details are being fetched.");
		LoanMaster loanMaster = new LoanMaster();
		CustomerBean customer = new CustomerBean();
		int applicantNumberTemp = 0;
		BigDecimal uciTemp = null;
		Connection connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection
				.prepareStatement(QueryMapper.APPLICANT_NUM_FROM_LOAN_NUMBER);) {
			preparedStatement.setLong(1, loanNumber);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					applicantNumberTemp = resultSet.getInt("applicant_num");
				}
			}
		} catch (SQLException e) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp) {
				LOGGER.error("SQL Exception occuring while fetching EMI details.");
				System.out.println(exp.getMessage());
			}
		}

		try (PreparedStatement preparedStatement = connection
				.prepareStatement(QueryMapper.DETAILS_FROM_APPLICANT_NUM);) {
			preparedStatement.setLong(1, applicantNumberTemp);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {

					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					loanMaster.setCustomerBean(customer);
					loanMaster.setLoanNumber(loanNumber);
					loanMaster.setApplicationNumber(resultSet.getInt("applicant_num"));
					loanMaster.setLoanAmount(resultSet.getDouble("loan_amount"));
					loanMaster.setLoanTenure(resultSet.getInt("loan_tenure"));
					loanMaster.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					loanMaster.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					loanMaster.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						loanMaster.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						loanMaster.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						loanMaster.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						loanMaster.setLoanType(LoanType.VEHICLE_LOAN);
					}
					loanMaster.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					if (resultSet.getString("status").equals("pending")) {
						loanMaster.setLoanStatus(LoanStatus.PENDING);
					} else if (resultSet.getString("status").equals("closed")) {
						loanMaster.setLoanStatus(LoanStatus.CLOSED);
					} else if (resultSet.getString("status").equals("approved")) {
						loanMaster.setLoanStatus(LoanStatus.APPROVED);
					} else if (resultSet.getString("status").equals("declined")) {
						loanMaster.setLoanStatus(LoanStatus.DECLINED);
					}
					loanMaster.setNextEmiDate(resultSet.getDate("next_emi_date").toLocalDate());

				}
			}
		} catch (SQLException exp) {
			LOGGER.error("SQL Exception occuring while fetching EMI details.");
			System.out.println(exp.getMessage());
		}
		return loanMaster;
	}

	@Override
	public CustomerBean getCustomerDetails(String userId) throws SQLException, IBSException {
		LOGGER.info("Customer details are being fetched.");
		Connection connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.GET_CUSTOMER_DETAILS);) {
			preparedStatement.setString(1, userId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUserId(resultSet.getString("user_id"));
				}
			}

		}
		return customer;
	}

	// LoanDetails
	public List<LoanMaster> getHistory(String userId) throws IBSException { /* getting list of loans */
		LOGGER.info("Customer is viewing his loan history.");
		List<LoanMaster> loanMasters = new ArrayList<>();
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.SEL_THE_COMMON_ROWS);) {
			preparedStatement.setString(1, userId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {

				while (resultSet.next()) {
					LoanMaster loanMaster = new LoanMaster();
					CustomerBean customer = new CustomerBean();
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					loanMaster.setCustomerBean(customer);
					loanMaster.setLoanNumber(resultSet.getInt("loan_number"));
					loanMaster.setLoanAmount(resultSet.getDouble("loan_amount"));
					loanMaster.setLoanTenure(resultSet.getInt("loan_tenure"));
					loanMaster.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					loanMaster.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					loanMaster.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						loanMaster.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						loanMaster.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						loanMaster.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						loanMaster.setLoanType(LoanType.VEHICLE_LOAN);
					}
					loanMaster.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					loanMasters.add(loanMaster);
				}
			}
		}

		catch (SQLException exp) {
			LOGGER.error("SQL Exception occuring while fetching loan history.");
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORIOEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("IO Exception occuring while fetching loan history.");
				System.out.println(exp12.getMessage());
			}
		}
		return loanMasters;
	}

	// PreClosure
	public LoanMaster getPreClosureLoanDetails(long loanNumber) {
		LOGGER.info("PreClosure details are being fetched.");
		LoanMaster loanMaster = new LoanMaster();
		CustomerBean customer = new CustomerBean();
		Connection connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement2 = connection
				.prepareStatement(QueryMapper.DETAILS_FROM_LOAN_NUMBER);) {
			preparedStatement2.setLong(1, loanNumber);
			try (ResultSet resultSet = preparedStatement2.executeQuery()) {
				if (resultSet.next()) {
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					loanMaster.setCustomerBean(customer);
					loanMaster.setLoanNumber(loanNumber);
					loanMaster.setApplicationNumber(resultSet.getInt("applicant_num"));
					loanMaster.setLoanAmount(resultSet.getDouble("loan_amount"));
					loanMaster.setLoanTenure(resultSet.getInt("loan_tenure"));
					loanMaster.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					loanMaster.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					loanMaster.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						loanMaster.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						loanMaster.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						loanMaster.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						loanMaster.setLoanType(LoanType.VEHICLE_LOAN);
					}
					loanMaster.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
				}
			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp21) {
				LOGGER.error("SQL Exception occuring while fetching PreClosure details.");
				System.out.println(exp21.getMessage());
			}
		}

		return loanMaster;
	}

	@Override
	public boolean verifyLoanNumber(long loanNumber) { /* Verification of loan number (Pre Closure) */
		LOGGER.info("Verifying loan number");
		boolean check = false;
		int applicantNumTemp = 0;
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection
				.prepareStatement(QueryMapper.APPLICANT_NUM_FROM_LOAN_NUMBER);) {
			preparedStatement.setLong(1, loanNumber);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					applicantNumTemp = resultSet.getInt("applicant_num");
				}
			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp1) {
				LOGGER.error("SQL Exception occuring while verifying loan number.");
				System.out.println(exp1.getMessage());
			}
		}

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.APPLICANT_NUM_LOAN);) {
			preparedStatement.setInt(1, applicantNumTemp);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					if (resultSet.getInt("applicant_num") == applicantNumTemp) {
						check = true;
					}
				}
			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp1) {
				LOGGER.error("SQL Exception occuring while verifying loan number.");
				System.out.println(exp1.getMessage());
			}
		}

		return check;
	}

//
	public boolean sendPreClosureForVerification(LoanMaster loanMaster) {
		LOGGER.info("Sending PreClosure for verification");
		Connection connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_LOAN_STATUS);) {
			preparedStatement.setLong(1, loanMaster.getLoanNumber());
			preparedStatement.executeUpdate();
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp1) {
				LOGGER.error("SQL Exception occuring while sending PreClosure for verification.");
				System.out.println(exp1.getMessage());
			}
		}
		return true;
	}

	public boolean uploadDocument(Document document, LoanMaster loanMaster) throws IBSException {
		LOGGER.info("Document being uploaded");
		boolean isDone = false;
		FileInputStream inputStream = null;
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPLOAD_DOCUMENT);) {
			if (null == inputStream) {
				File uploadFile = new File(document.getPathOfDocument());
				inputStream = new FileInputStream(uploadFile);
				preparedStatement.setBinaryStream(1, inputStream);
				preparedStatement.setBigDecimal(2, new BigDecimal(loanMaster.getCustomerBean().getUCI()));
				preparedStatement.executeUpdate();
				isDone = true;
				connection.commit();
			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp1) {
				LOGGER.error("SQL Exception occuring while uploading document.");
				System.out.println(exp1.getMessage());
			}

		} catch (FileNotFoundException exp2) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
			} catch (IBSException exp31) {
				LOGGER.error("FileNotFound Exception occuring while uploading document.");
				System.out.println(exp31.getMessage());
			}
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					try {
						throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
					} catch (IBSException exp32) {
						LOGGER.error("FileNotFound Exception occuring while uploading document.");
						System.out.println(exp32.getMessage());
					}
				}
			}
		}
		return isDone;
	}

	@Override
	public boolean verifyCustomer(String userId) throws IBSException {
		LOGGER.info("Customer being verified by user id");
		boolean check = false;
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.VERIFY_CUSTOMER);) {
			preparedStatement.setString(1, userId);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					if (resultSet.getString("user_id").equals(userId)) {
						check = true;
					}
				}
			} catch (SQLException e) {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
				} catch (IBSException exp) {
					LOGGER.error("SQL Exception occuring while verifying customer.");
					System.out.println(exp.getMessage());
				}
			}

		} catch (SQLException exp1) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp11) {
				LOGGER.error("SQL Exception occuring while verifying customer.");
				System.out.println(exp11.getMessage());
			}
		}
		return check;
	}

	@Override
	public boolean sendLoanForVerification(LoanMaster loanMaster) throws IBSException {
		LOGGER.info("Sending loan for verification.");
		boolean check = false;
		BigDecimal uciTemp = null;
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.GET_UCI);) {
			preparedStatement.setString(1, loanMaster.getCustomerBean().getUserId());
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (null == uciTemp) {
					if (resultSet.next()) {
						uciTemp = resultSet.getBigDecimal("uci");
					}
				}

			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while verifying loan.");
				System.out.println(exp12.getMessage());
			}
		}

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.INS_APP);) {
			preparedStatement.setLong(1, loanMaster.getApplicationNumber());
			preparedStatement.setBigDecimal(2, uciTemp);
			preparedStatement.setString(3, "pending");
			preparedStatement.setDouble(4, loanMaster.getLoanAmount());
			preparedStatement.setInt(5, loanMaster.getLoanTenure());
			preparedStatement.setInt(6, loanMaster.getTotalNumberOfEmis());
			preparedStatement.setDouble(7, loanMaster.getEmiAmount());
			preparedStatement.setDate(8, Date.valueOf(loanMaster.getAppliedDate()));
			if (loanMaster.getLoanType() == LoanType.HOME_LOAN) {
				preparedStatement.setInt(9, 1);
			} else if (loanMaster.getLoanType() == LoanType.EDUCATION_LOAN) {
				preparedStatement.setInt(9, 2);
			} else if (loanMaster.getLoanType() == LoanType.PERSONAL_LOAN) {
				preparedStatement.setInt(9, 3);
			} else if (loanMaster.getLoanType() == LoanType.VEHICLE_LOAN) {
				preparedStatement.setInt(9, 4);
			}
			preparedStatement.setDouble(10, loanMaster.getBalance());
			preparedStatement.setInt(11, loanMaster.getNumberOfEmis());
			preparedStatement.setDate(12, Date.valueOf(loanMaster.getAppliedDate().plusMonths(1)));
			check = true;
			preparedStatement.executeUpdate();
			connection.commit();
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while verifying loan.");
				System.out.println(exp12.getMessage());
			}

		}

		return check;
	}

	@Override
	public long generateApplicantNumber() throws IBSException {
		LOGGER.info("Applicant number is generated while applying for a new loan");
		Connection connection = OracleDataBaseUtil.getConnection();
		long newApplicantNumber = 0;
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.GENERATE_APPLICANT_NUM);) {
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					newApplicantNumber = resultSet.getLong(1);
				}

			}
		} catch (SQLException e) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while generating applicant number.");
				System.out.println(exp12.getMessage());
			}

		}
		return newApplicantNumber;
	}

}