package com.cg.ibs.loanmgmt.dao;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.cg.ibs.loanmgmt.bean.CustomerBean;
import com.cg.ibs.loanmgmt.bean.LoanMaster;
import com.cg.ibs.loanmgmt.bean.LoanStatus;
import com.cg.ibs.loanmgmt.bean.LoanType;
import com.cg.ibs.loanmgmt.exception.ExceptionMessages;
import com.cg.ibs.loanmgmt.exception.IBSException;
import com.cg.ibs.loanmgmt.service.BankServiceImpl;
import com.cg.ibs.loanmgmt.util.OracleDataBaseUtil;

import org.apache.log4j.Logger;

public class BankDaoImpl implements BankDao {

	LoanMaster loanMaster = new LoanMaster();
	Connection connection;
	private static Logger LOGGER = Logger.getLogger(BankDaoImpl.class);

	@Override
	public long generateLoanNumber() throws IBSException {
		LOGGER.info("Loan number for a newly applied loan is generated.");
		Connection connection = OracleDataBaseUtil.getConnection();
		long newLoanNumber = 0;
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.GENERATE_LOAN_NUM);) {
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					newLoanNumber = resultSet.getLong(1);
				}

			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while generating loan number.");
				System.out.println(exp12.getMessage());
			}
		}
		return newLoanNumber;
	}

	@Override
	public boolean saveLoan(LoanMaster loanMaster) throws SQLException {
		LOGGER.info("Loan is being saved");
		boolean confirm = false;
		connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.INS_LOAN);) {
			preparedStatement.setString(1, "approved");
			preparedStatement.setLong(2, loanMaster.getApplicationNumber());
			preparedStatement.executeUpdate();
		} catch (SQLException exp1) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while saving loan.");
				System.out.println(exp12.getMessage());
			}
		}
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.APPROVE_LOAN);) {
			preparedStatement.setLong(2, loanMaster.getLoanNumber());
			preparedStatement.setLong(1, loanMaster.getApplicationNumber());
			preparedStatement.executeUpdate();
			confirm = true;
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while saving loan.");
				System.out.println(exp12.getMessage());
			}
		}
		return confirm;
	}

	@Override
	public Map<Long, LoanMaster> getLoanDetailsForVerification() throws IBSException {
		
		Connection connection = OracleDataBaseUtil.getConnection();
		Map<Long, LoanMaster> pendingLoans = new HashMap<>();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.GET_PENDING_LOAN);) {
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					LoanMaster pendingLoan = new LoanMaster();
					CustomerBean customer = new CustomerBean();
					pendingLoan.setApplicationNumber(resultSet.getLong("applicant_num"));
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					pendingLoan.setCustomerBean(customer);
					pendingLoan.setLoanAmount(resultSet.getDouble("loan_amount"));
					pendingLoan.setLoanTenure(resultSet.getInt("loan_tenure"));
					pendingLoan.setInterestRate(resultSet.getFloat("interest_rate"));
					pendingLoan.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						pendingLoan.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						pendingLoan.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						pendingLoan.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						pendingLoan.setLoanType(LoanType.VEHICLE_LOAN);
					}
					pendingLoan.setLoanStatus(LoanStatus.PENDING);
					pendingLoan.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					pendingLoan.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					pendingLoans.put(pendingLoan.getApplicationNumber(), pendingLoan); // Storing details in map
					
				} // document need to be downloaded
				LOGGER.info("Loan details being fetched from database");
			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while fetching details from database.");
				System.out.println(exp12.getMessage());
			}

		}
		return pendingLoans;
	}

	@Override
	public boolean downloadDocument(long applicationNumber) throws IBSException {
		LOGGER.info("Document is being downloaded");
		boolean check = false;
		Connection connection = OracleDataBaseUtil.getConnection();
		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DOWNLOAD_DOCUMENT);) {
			preparedStatement.setLong(1, applicationNumber);
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				if (resultSet.next()) {
					Blob getDocument = resultSet.getBlob("document");
					FileOutputStream fileOutputStream = new FileOutputStream("./download" + applicationNumber + ".pdf");
					fileOutputStream.write(getDocument.getBytes(1, (int) getDocument.length()));
					fileOutputStream.flush();
					fileOutputStream.close();
					check = true;
				}
			} catch (FileNotFoundException e) {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORFILENOTFOUND);
				} catch (IBSException exp12) {
					LOGGER.error("FileNotFound Exception occuring while downloading document.");
					System.out.println(exp12.getMessage());
				}

			} catch (IOException e) {
				try {
					throw new IBSException(ExceptionMessages.MESSAGEFORIOEXCEPTION);
				} catch (IBSException exp12) {
					LOGGER.error("IO Exception occuring while downloading document.");
					System.out.println(exp12.getMessage());
				}
			}
		} catch (SQLException e) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while downloading document.");
				System.out.println(exp12.getMessage());
			}
		}
		return check;
	}

	@Override
	public LoanMaster updatePreClosure(LoanMaster loanMaster) { /*
																 * Updating EMI after approval of PreClosure
																 */
		LOGGER.info("PreClosure is being updated");
		CustomerBean customer = new CustomerBean();
		connection = OracleDataBaseUtil.getConnection();

		try (PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_PRECLOSURE);) {

			preparedStatement.setInt(1, loanMaster.getTotalNumberOfEmis());
			preparedStatement.setLong(2, loanMaster.getLoanNumber());
			preparedStatement.executeUpdate();
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while updating PreClosure");
				System.out.println(exp12.getMessage());
			}
		}

		try (PreparedStatement preparedStatement2 = connection
				.prepareStatement(QueryMapper.DETAILS_FROM_LOAN_NUMBER_BANK);) {

			preparedStatement2.setLong(1, loanMaster.getLoanNumber());
			try (ResultSet resultSet = preparedStatement2.executeQuery()) {
				if (resultSet.next()) {
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					loanMaster.setCustomerBean(customer);
					loanMaster.setApplicationNumber(resultSet.getInt("applicant_num"));
					loanMaster.setLoanAmount(resultSet.getDouble("loan_amount"));
					loanMaster.setLoanTenure(resultSet.getInt("loan_tenure"));
					loanMaster.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					loanMaster.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					loanMaster.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						loanMaster.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						loanMaster.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						loanMaster.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						loanMaster.setLoanType(LoanType.VEHICLE_LOAN);
					}
					loanMaster.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					loanMaster.setNextEmiDate(null);
				}
			}
		} catch (SQLException exp1) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp) {
				LOGGER.error("SQL Exception occuring while updating PreClosure");
				System.out.println(exp.getMessage());
			}
		}
		return loanMaster;
	}

	@Override
	public Map<Long, LoanMaster> getPreClosureDetailsForVerification() throws IBSException {
		LOGGER.info("PreClosure details are being fetched.");
		Connection connection = OracleDataBaseUtil.getConnection();
		Map<Long, LoanMaster> pendingPreClosures = new HashMap<>();

		try (PreparedStatement preparedStatement = connection
				.prepareStatement(QueryMapper.UPDATE_PRE_CLOSURE_STATUS);) {
			try (ResultSet resultSet = preparedStatement.executeQuery()) {
				while (resultSet.next()) {
					LoanMaster pendingPreClosure = new LoanMaster();
					CustomerBean customer = new CustomerBean();
					pendingPreClosure.setApplicationNumber(resultSet.getLong("applicant_num"));
					customer.setFirstName(resultSet.getString("first_name"));
					customer.setLastName(resultSet.getString("last_name"));
					customer.setUCI(resultSet.getBigDecimal("uci").toBigInteger());
					customer.setUserId(resultSet.getString("user_id"));
					pendingPreClosure.setCustomerBean(customer);
					pendingPreClosure.setLoanNumber(resultSet.getLong("loan_number"));
					pendingPreClosure.setLoanAmount(resultSet.getDouble("loan_amount"));
					pendingPreClosure.setLoanTenure(resultSet.getInt("loan_tenure"));
					pendingPreClosure.setInterestRate(resultSet.getFloat("interest_rate"));
					pendingPreClosure.setEmiAmount(resultSet.getDouble("emi_amount"));
					if (resultSet.getInt("type_id") == 1) {
						pendingPreClosure.setLoanType(LoanType.HOME_LOAN);
					} else if (resultSet.getInt("type_id") == 2) {
						pendingPreClosure.setLoanType(LoanType.EDUCATION_LOAN);
					} else if (resultSet.getInt("type_id") == 3) {
						pendingPreClosure.setLoanType(LoanType.PERSONAL_LOAN);
					} else if (resultSet.getInt("type_id") == 4) {
						pendingPreClosure.setLoanType(LoanType.VEHICLE_LOAN);
					}
					pendingPreClosure.setNumberOfEmis(resultSet.getInt("num_of_emis_paid"));
					pendingPreClosure.setTotalNumberOfEmis(resultSet.getInt("total_num_of_emis"));
					pendingPreClosure.setAppliedDate(resultSet.getDate("applied_date").toLocalDate());
					pendingPreClosures.put(pendingPreClosure.getApplicationNumber(), pendingPreClosure); // Storing
																											// details
																											// in map
				}

			}
		} catch (SQLException exp) {
			try {
				throw new IBSException(ExceptionMessages.MESSAGEFORSQLEXCEPTION);
			} catch (IBSException exp12) {
				LOGGER.error("SQL Exception occuring while fetching details for a PreClosure");
				System.out.println(exp12.getMessage());
			}
		}
		return pendingPreClosures;
	}
}
